#ifndef GUARD_GENERATOR_H
#define GUARD_GENERATOR_H

#include "sound_block.h"

class generator: public sound_block {
	sound_block *after;
};

#endif
