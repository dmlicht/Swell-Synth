#include "synth.h"
#include "generator.h"

synth::synth(generator *start_block){
	ticks = 0;
	before = start_block;
	bt = SYNTH;
}

void synth::get_samps(float *buffer, int buffer_size){
  float block_reciever[buffer_size];
  before->get_samps(&block_reciever, buffer_size);
  for (int i = 0; i < buffer_size; ++i){
    *buffer = *block_reciever;
    ++buffer;
    ++block_reciever;
  }
}

void synth::get_samps(float *buffer){
  float block_reciever[synth.get_ksmps()];
  block->fill_buff(&block_reciever, synth.get_ksmps());
  for (int i = 0; i < synth.get_ksmps(); ++i){
    *buffer = *block_reciever;
    ++buffer;
    ++block_reciever;
  }
}

   /* setters */

static void synth::initialize(){
	sample_rate = 44100;
	ksmps = 128;
	nchan = 1;
}

static void synth::set_sample_rate(int){
  sample_rate = sr;
}

static void synth::set_ksmps(int cp){
  ksmps = cp;
}

static void synth::set_nchan(int nc){
  nchan = nc
}

  /* getters */
static int synth::get_sample_rate(){
  return sample_rate;
}

static int synth::get_ksmps(){
  return control_period;
}

static int synth::get_nchan(){
  return nchan;
}
