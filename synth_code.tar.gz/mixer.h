#ifndef GUARD_MIXER_H
#define GUARD_MIXER_H

#include <iostream>
#include <cstdlib>
#include <cmath>
#include "sound_block.h"
#include "mixee.h"
#include "generator.h"
#include <vector>

class mixer : public sound_block {

private:
	std::vector<mixee *> mixees;
	void adjust_scale();
public:
  void add_mixee(generator *); //add a generator to be mixed
	void add_mixee(generator *, float);
	mixer(mixee *);
	~mixer();
};
#endif
