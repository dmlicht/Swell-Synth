#include "processor.h"

processor::processor(){
	bt = PROCESSOR;
}
