#ifndef GUARD_SYNTH_H
#define GUARD_SYNTH_H

#include "sound_block.h"

class generator: public sound_block {
	sound_block *after;
};

#endif
