#ifndef GUARD_PROCESSOR_H
#define GUARD_PROCESSOR_H

#include "wavetable.h"
#include "envelope.h"

class processor {
private:
  processor *after;		//where data is sent
  processor *before;		//processor that gives data to be processed

public:
  void add_after(processor*);	
	void set(sound_block *, sound_block *);		//Make a friend function so that only other soundblocks can set
	processor();
};

#endif
