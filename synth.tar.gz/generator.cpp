#include "generator.h"

public void generator::set(sound_block *before, sound_block* after){
	this.after = after;
}

generator::generator(){
	bt = GENERATOR;
}
