#include "sound_block.h"
#include "mixer.h"

mixer::get_samps(float *buffer, int buffer_size){
	int inputs = mixees.size;
	float buffer_input;
	for (int i = 0; i < inputs; ++i){
		mixees.at(i)->before->get_samps(mixees.at(i)->pre_mix, synth.get_ksmps()); 	//Fill all buffers
  }
	for (int i = 0; i < buffer_size; ++i){
		buffer_input = 0;
	  for (int j = 0; j < inputs; ++j){
			buffer_input += (mixees.at(j)->premix[i] * mixees.at(j)->scale);
		}
		*buffer = buffer_input;
	}
}

//changes the scale of all the mixees to add up to 1 to help avoid clipping
mixer::adjust_scale(){
	float total_weight = 0;
	for (int i = 0; i < mixees.size; ++i){
		total_weight += mixees.at(i)->scale;
	}
	float fix_value = 1.0 / total_weight;
	for (int i = 0; i < mixees.size; ++i){
		mixees.at(i)->scale = mixees.at(i)->scale * fix_value;
	}
}

mixer::add_mixee(generator *new_wave){
	mixees.push_back(mixee *new_mixee);
}

mixer::add_mixee(generator *new_wave, float scale){
	mixees.push_back(new mixee(new_wave, scale));
}

mixer::mixer(generator *starter){
	mixees.push_back(new mixee(starter, 1.0));
	starter.add_back(&this);
	bt = MIXER;
}

mixer::~mixer(){
	int inputs = mixees.size;
	for (int i = inputs; i > 0 ; --i){
		delete mixees.at(i);
	}
}

//check which position the mixee was previously attached at, then adjust chain accordingly
void sound_block::set_front_m(sound_block *before, sound_block *pre){
	int i = 0;
  bool keep_going = true
	while (i < mixees.size && keep_going){
		if (mixees.at(i).before == pre){
			mixees.at(i).before = before;
			keep_going = false;
		}
	}
}

void mixer::set(sound_block *before, sound_block *after){
	this.set_front_m(before, before);
	this.after = after;
